# Instagram Engagement Rate Calculator

## Overview

This is a full-stack web application that calculates Instagram engagement rates for social media analytics. The application provides users with a comprehensive tool to measure their Instagram performance by analyzing follower counts, post metrics, likes, and comments. It includes industry benchmarks for comparison and actionable tips to improve engagement rates. The app features a modern, mobile-responsive interface built with React and styled using Tailwind CSS with shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation resolvers
- **Mobile Support**: Responsive design with mobile-first approach and touch-friendly interactions

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for engagement calculations and industry benchmarks
- **Validation**: Zod schemas for request/response validation
- **Error Handling**: Centralized error middleware with proper HTTP status codes
- **Development**: Hot reload with Vite integration for full-stack development

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **In-Memory Storage**: Fallback MemStorage implementation for development/testing
- **Data Models**: Users table and engagement calculations table with proper relationships

### Authentication and Authorization
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **User Model**: Basic user schema with username/password fields
- **Security**: Prepared for authentication implementation with user storage interfaces

### Component Architecture
- **Design System**: Consistent component library with variants and theming
- **Accessibility**: ARIA-compliant components from Radix UI
- **Performance**: Lazy loading and optimized rendering with React best practices
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database client
- **drizzle-orm**: Type-safe ORM with schema validation
- **drizzle-zod**: Integration between Drizzle and Zod for schema validation
- **express**: Web framework for Node.js backend
- **vite**: Build tool and development server

### UI and Styling Dependencies
- **@radix-ui/***: Comprehensive collection of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **clsx**: Utility for constructing className strings
- **lucide-react**: Icon library with consistent design

### Data Management Dependencies
- **@tanstack/react-query**: Server state management and caching
- **@hookform/resolvers**: Form validation resolvers for React Hook Form
- **zod**: TypeScript-first schema validation
- **date-fns**: Date utility library for formatting and manipulation

### Development Dependencies
- **tsx**: TypeScript execution engine for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development tools and error handling

### Mobile and User Experience
- **embla-carousel-react**: Touch-friendly carousel component
- **vaul**: Drawer component for mobile interfaces
- **wouter**: Minimalist routing for React applications