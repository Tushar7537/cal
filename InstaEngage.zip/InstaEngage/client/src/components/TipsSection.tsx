import { Lightbulb, Clock, Hash, MessageCircle, Target, Camera, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const tips = [
  {
    icon: Clock,
    title: "Post Consistently",
    description: "Maintain a regular posting schedule to keep your audience engaged and your content visible in their feeds.",
    color: "bg-teal-100 text-teal-600",
  },
  {
    icon: Hash,
    title: "Use Relevant Hashtags",
    description: "Research and use targeted hashtags that your ideal audience searches for to increase discoverability.",
    color: "bg-orange-100 text-orange-600",
  },
  {
    icon: MessageCircle,
    title: "Engage with Your Audience",
    description: "Respond to comments and engage with your followers' content to build meaningful relationships.",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: Target,
    title: "Know Your Audience",
    description: "Create content that resonates with your target demographic and their interests.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: Camera,
    title: "Create Quality Content",
    description: "Focus on high-quality visuals and compelling captions that encourage interaction.",
    color: "bg-pink-100 text-pink-600",
  },
  {
    icon: Users,
    title: "Collaborate with Others",
    description: "Partner with other creators or brands to expand your reach and attract new followers.",
    color: "bg-green-100 text-green-600",
  },
];

export default function TipsSection() {
  return (
    <div className="bg-gradient-to-r from-teal-50 to-orange-50 rounded-2xl p-6 sm:p-8">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center justify-center">
          <Lightbulb className="text-yellow-500 mr-3 h-6 w-6" />
          Boost Your Engagement Rate
        </h3>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Discover proven strategies to increase your Instagram engagement and grow your audience organically.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tips.map((tip, index) => (
          <Card key={index} className="bg-white shadow-sm hover-lift">
            <CardContent className="p-6">
              <div className={`w-12 h-12 ${tip.color} rounded-lg flex items-center justify-center mb-4`}>
                <tip.icon className="h-5 w-5" />
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">{tip.title}</h4>
              <p className="text-gray-600 text-sm leading-relaxed">{tip.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
