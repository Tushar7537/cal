import { useState, useEffect } from "react";
import { Calculator, Users, Calendar, Image, Heart, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";

interface CalculatorFormProps {
  onCalculate: (data: {
    followers: number;
    posts: number;
    likes: number;
    comments: number;
    period: string;
  }) => void;
}

export default function CalculatorForm({ onCalculate }: CalculatorFormProps) {
  const [followers, setFollowers] = useState("");
  const [posts, setPosts] = useState("");
  const [likes, setLikes] = useState("");
  const [comments, setComments] = useState("");
  const [period, setPeriod] = useState("30");

  const periodOptions = [
    { value: "7", label: "Last 7 days" },
    { value: "30", label: "Last 30 days" },
    { value: "90", label: "Last 90 days" },
  ];

  useEffect(() => {
    if (followers && posts && likes && comments) {
      onCalculate({
        followers: parseInt(followers) || 0,
        posts: parseInt(posts) || 0,
        likes: parseInt(likes) || 0,
        comments: parseInt(comments) || 0,
        period,
      });
    }
  }, [followers, posts, likes, comments, period, onCalculate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCalculate({
      followers: parseInt(followers) || 0,
      posts: parseInt(posts) || 0,
      likes: parseInt(likes) || 0,
      comments: parseInt(comments) || 0,
      period,
    });
  };

  return (
    <Card className="hover-lift">
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center mr-3">
            <Calculator className="text-teal-600 h-4 w-4" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900">Account Metrics</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Followers Input */}
          <div className="space-y-2">
            <Label htmlFor="followers" className="flex items-center text-sm font-medium text-gray-700">
              <Users className="mr-2 h-4 w-4 text-teal-500" />
              Total Followers
            </Label>
            <Input
              id="followers"
              type="number"
              placeholder="e.g., 10000"
              value={followers}
              onChange={(e) => setFollowers(e.target.value)}
              className="h-12 text-base focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              min="0"
            />
          </div>

          {/* Time Period Selection */}
          <div className="space-y-2">
            <Label className="flex items-center text-sm font-medium text-gray-700">
              <Calendar className="mr-2 h-4 w-4 text-teal-500" />
              Time Period
            </Label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {periodOptions.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={period === option.value ? "default" : "outline"}
                  onClick={() => setPeriod(option.value)}
                  className={`h-10 text-sm font-medium transition-all ${
                    period === option.value
                      ? "bg-teal-500 text-white border-teal-500 hover:bg-teal-600"
                      : "bg-white text-gray-700 border-gray-300 hover:border-gray-400"
                  }`}
                >
                  {option.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Posts Input */}
          <div className="space-y-2">
            <Label htmlFor="posts" className="flex items-center text-sm font-medium text-gray-700">
              <Image className="mr-2 h-4 w-4 text-orange-500" />
              Number of Posts
            </Label>
            <Input
              id="posts"
              type="number"
              placeholder="e.g., 15"
              value={posts}
              onChange={(e) => setPosts(e.target.value)}
              className="h-12 text-base focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              min="1"
            />
          </div>

          {/* Total Likes Input */}
          <div className="space-y-2">
            <Label htmlFor="likes" className="flex items-center text-sm font-medium text-gray-700">
              <Heart className="mr-2 h-4 w-4 text-red-500" />
              Total Likes
            </Label>
            <Input
              id="likes"
              type="number"
              placeholder="e.g., 5000"
              value={likes}
              onChange={(e) => setLikes(e.target.value)}
              className="h-12 text-base focus:ring-2 focus:ring-red-500 focus:border-transparent"
              min="0"
            />
          </div>

          {/* Total Comments Input */}
          <div className="space-y-2">
            <Label htmlFor="comments" className="flex items-center text-sm font-medium text-gray-700">
              <MessageCircle className="mr-2 h-4 w-4 text-blue-500" />
              Total Comments
            </Label>
            <Input
              id="comments"
              type="number"
              placeholder="e.g., 200"
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              className="h-12 text-base focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              min="0"
            />
          </div>

          {/* Calculate Button */}
          <Button
            type="submit"
            className="w-full h-12 gradient-bg text-white font-semibold text-lg hover:opacity-90 transition-opacity"
          >
            <Calculator className="mr-2 h-5 w-5" />
            Calculate Engagement Rate
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
