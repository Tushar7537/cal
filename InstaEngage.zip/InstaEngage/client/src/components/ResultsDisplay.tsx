import { useState, useEffect } from "react";
import { PieChart, Download, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface ResultsDisplayProps {
  followers: number;
  posts: number;
  likes: number;
  comments: number;
}

export default function ResultsDisplay({ followers, posts, likes, comments }: ResultsDisplayProps) {
  const [animatedRate, setAnimatedRate] = useState(0);
  const [animatedCircle, setAnimatedCircle] = useState(0);

  const totalEngagements = likes + comments;
  const engagementRate = followers > 0 && posts > 0 
    ? ((totalEngagements / (followers * posts)) * 100)
    : 0;
  
  const likesRate = followers > 0 && posts > 0 
    ? ((likes / (followers * posts)) * 100)
    : 0;
  
  const commentsRate = followers > 0 && posts > 0 
    ? ((comments / (followers * posts)) * 100)
    : 0;

  const avgLikesPerPost = posts > 0 ? Math.round(likes / posts) : 0;
  const avgCommentsPerPost = posts > 0 ? Math.round(comments / posts) : 0;

  const getEngagementStatus = (rate: number) => {
    if (rate >= 6) {
      return { text: "Excellent", icon: TrendingUp, color: "text-green-600" };
    } else if (rate >= 3) {
      return { text: "Good", icon: TrendingUp, color: "text-blue-600" };
    } else if (rate >= 1) {
      return { text: "Average", icon: Minus, color: "text-yellow-600" };
    } else {
      return { text: "Below Average", icon: TrendingDown, color: "text-red-600" };
    }
  };

  const status = getEngagementStatus(engagementRate);
  const StatusIcon = status.icon;

  // Animate the rate counter
  useEffect(() => {
    const timer = setTimeout(() => {
      if (animatedRate < engagementRate) {
        setAnimatedRate(Math.min(animatedRate + engagementRate / 50, engagementRate));
      }
    }, 20);
    return () => clearTimeout(timer);
  }, [animatedRate, engagementRate]);

  // Animate the circle
  useEffect(() => {
    const timer = setTimeout(() => {
      const targetCircle = Math.min(engagementRate * 10, 100);
      if (animatedCircle < targetCircle) {
        setAnimatedCircle(Math.min(animatedCircle + targetCircle / 50, targetCircle));
      }
    }, 20);
    return () => clearTimeout(timer);
  }, [animatedCircle, engagementRate]);

  const handleExport = () => {
    const data = {
      engagementRate: engagementRate.toFixed(1),
      avgLikesPerPost,
      avgCommentsPerPost,
      likesRate: likesRate.toFixed(1),
      commentsRate: commentsRate.toFixed(1),
      status: status.text,
      timestamp: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'instagram-engagement-results.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const circumference = 2 * Math.PI * 15.9155;
  const strokeDasharray = `${(animatedCircle / 100) * circumference}, ${circumference}`;

  return (
    <Card className="hover-lift">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
              <PieChart className="text-orange-600 h-4 w-4" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900">Engagement Results</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={handleExport} className="text-gray-500 hover:text-gray-700">
            <Download className="h-4 w-4" />
          </Button>
        </div>

        {/* Main Engagement Rate */}
        <div className="text-center mb-8">
          <div className="relative w-32 h-32 mx-auto mb-4">
            <svg className="w-32 h-32" viewBox="0 0 36 36">
              <path
                d="M18 2.0845
                 a 15.9155 15.9155 0 0 1 0 31.831
                 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#E5E7EB"
                strokeWidth="3"
              />
              <path
                d="M18 2.0845
                 a 15.9155 15.9155 0 0 1 0 31.831
                 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="url(#gradient)"
                strokeWidth="3"
                strokeDasharray={strokeDasharray}
                className="progress-ring"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#14B8A6" />
                  <stop offset="100%" stopColor="#F97316" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-3xl font-bold text-gray-900 animate-counter">
                {animatedRate.toFixed(1)}%
              </span>
            </div>
          </div>
          <p className="text-lg font-medium text-gray-700 mb-2">Overall Engagement Rate</p>
          <p className={`text-sm font-medium flex items-center justify-center ${status.color}`}>
            <StatusIcon className="mr-1 h-4 w-4" />
            {status.text}
          </p>
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-teal-600 mb-1">
              {avgLikesPerPost.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Avg. Likes per Post</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-orange-600 mb-1">
              {avgCommentsPerPost.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">Avg. Comments per Post</div>
          </div>
        </div>

        {/* Engagement Breakdown */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-600">Likes Engagement</span>
              <span className="font-medium">{likesRate.toFixed(1)}%</span>
            </div>
            <Progress 
              value={Math.min((likesRate / engagementRate) * 100, 100)} 
              className="h-2"
            />
          </div>
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-600">Comments Engagement</span>
              <span className="font-medium">{commentsRate.toFixed(1)}%</span>
            </div>
            <Progress 
              value={Math.min((commentsRate / engagementRate) * 100, 100)} 
              className="h-2"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
