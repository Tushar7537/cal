import { useState } from "react";
import { Calculator, HelpCircle, Share2, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { toast } = useToast();

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Instagram Engagement Rate Calculator',
          text: 'Calculate your Instagram engagement rate with this free tool!',
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "The link has been copied to your clipboard.",
      });
    }
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 gradient-bg rounded-lg flex items-center justify-center">
              <Calculator className="text-white h-5 w-5" />
            </div>
            <h1 className="text-xl font-bold text-gray-900 hidden sm:block">
              Instagram Engagement Calculator
            </h1>
            <h1 className="text-lg font-bold text-gray-900 sm:hidden">
              IG Calculator
            </h1>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
              <HelpCircle className="mr-2 h-4 w-4" />
              Help
            </Button>
            <Button
              onClick={handleShare}
              className="bg-teal-500 hover:bg-teal-600 text-white"
              size="sm"
            >
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-2">
              <Button variant="ghost" className="justify-start text-gray-600">
                <HelpCircle className="mr-2 h-4 w-4" />
                Help
              </Button>
              <Button
                onClick={handleShare}
                className="justify-start bg-teal-500 hover:bg-teal-600 text-white"
              >
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
