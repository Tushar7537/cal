import { Building2 } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const industries = [
  {
    name: "E-commerce",
    emoji: "🛍️",
    average: 1.2,
    good: 2.0,
  },
  {
    name: "Fashion",
    emoji: "🎨",
    average: 2.1,
    good: 3.0,
  },
  {
    name: "Food & Drink",
    emoji: "🍔",
    average: 3.8,
    good: 5.0,
  },
  {
    name: "Business",
    emoji: "💼",
    average: 1.5,
    good: 2.5,
  },
  {
    name: "Fitness",
    emoji: "💪",
    average: 2.8,
    good: 4.0,
  },
  {
    name: "Travel",
    emoji: "✈️",
    average: 2.4,
    good: 3.5,
  },
  {
    name: "Beauty",
    emoji: "💄",
    average: 3.2,
    good: 4.5,
  },
  {
    name: "Technology",
    emoji: "📱",
    average: 1.8,
    good: 2.8,
  },
];

export default function IndustryBenchmarks() {
  return (
    <Card className="hover-lift">
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
            <Building2 className="text-purple-600 h-4 w-4" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900">Industry Benchmarks</h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {industries.map((industry) => (
            <div
              key={industry.name}
              className="text-center p-4 border border-gray-200 rounded-lg hover:border-teal-300 transition-colors cursor-pointer"
            >
              <div className="text-2xl mb-2">{industry.emoji}</div>
              <div className="font-semibold text-gray-900 mb-1 text-sm">{industry.name}</div>
              <div className="text-xs text-gray-600 mb-2">Average: {industry.average}%</div>
              <div className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                Good: {industry.good}%+
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Note:</strong> These benchmarks are based on industry averages. Your specific 
            niche and audience may have different engagement patterns.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
