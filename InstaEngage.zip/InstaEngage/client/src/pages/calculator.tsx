import { useState } from "react";
import { Rocket, Download, Share2 } from "lucide-react";
import Header from "@/components/Header";
import CalculatorForm from "@/components/CalculatorForm";
import ResultsDisplay from "@/components/ResultsDisplay";
import IndustryBenchmarks from "@/components/IndustryBenchmarks";
import TipsSection from "@/components/TipsSection";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface CalculationData {
  followers: number;
  posts: number;
  likes: number;
  comments: number;
  period: string;
}

export default function Calculator() {
  const [calculationData, setCalculationData] = useState<CalculationData>({
    followers: 0,
    posts: 0,
    likes: 0,
    comments: 0,
    period: "30",
  });
  const { toast } = useToast();

  const handleCalculate = (data: CalculationData) => {
    setCalculationData(data);
  };

  const handleExport = () => {
    const engagementRate = calculationData.followers > 0 && calculationData.posts > 0 
      ? ((calculationData.likes + calculationData.comments) / (calculationData.followers * calculationData.posts) * 100)
      : 0;

    const results = {
      ...calculationData,
      engagementRate: engagementRate.toFixed(1),
      avgLikesPerPost: calculationData.posts > 0 ? Math.round(calculationData.likes / calculationData.posts) : 0,
      avgCommentsPerPost: calculationData.posts > 0 ? Math.round(calculationData.comments / calculationData.posts) : 0,
      timestamp: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'instagram-engagement-analysis.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: "Results exported!",
      description: "Your engagement analysis has been downloaded.",
    });
  };

  const handleShare = async () => {
    const engagementRate = calculationData.followers > 0 && calculationData.posts > 0 
      ? ((calculationData.likes + calculationData.comments) / (calculationData.followers * calculationData.posts) * 100)
      : 0;

    const shareText = `My Instagram engagement rate is ${engagementRate.toFixed(1)}%! Calculate yours with this free tool.`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Instagram Engagement Rate Calculator',
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      await navigator.clipboard.writeText(`${shareText} ${window.location.href}`);
      toast({
        title: "Shared to clipboard!",
        description: "Your results and the calculator link have been copied.",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 md:pb-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Calculate Your Instagram{" "}
            <span className="bg-gradient-to-r from-teal-500 to-orange-500 bg-clip-text text-transparent">
              Engagement Rate
            </span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Measure your Instagram performance with our comprehensive engagement rate calculator. 
            Get insights into your content's effectiveness and compare against industry benchmarks.
          </p>
        </div>

        {/* Calculator Section */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <CalculatorForm onCalculate={handleCalculate} />
          <ResultsDisplay
            followers={calculationData.followers}
            posts={calculationData.posts}
            likes={calculationData.likes}
            comments={calculationData.comments}
          />
        </div>

        {/* Industry Benchmarks */}
        <div className="mb-12">
          <IndustryBenchmarks />
        </div>

        {/* Tips Section */}
        <div className="mb-12">
          <TipsSection />
        </div>

        {/* Historical Comparison */}
        <Card className="mb-12 hover-lift">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                  <Rocket className="text-blue-600 h-4 w-4" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Track Your Progress</h3>
              </div>
            </div>

            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Rocket className="h-8 w-8 text-gray-400" />
              </div>
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Coming Soon</h4>
              <p className="text-gray-600 mb-4">
                Save your calculations and track your engagement rate over time to see your growth.
              </p>
              <Button className="gradient-bg text-white hover:opacity-90">
                Get Notified
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-600 mb-4">
              Get more insights and grow your Instagram presence with advanced analytics tools.
            </p>
            <Button className="gradient-bg text-white hover:opacity-90">
              <Rocket className="mr-2 h-4 w-4" />
              Explore Growth Tools
            </Button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 md:hidden z-40">
        <div className="flex space-x-3">
          <Button 
            variant="outline" 
            className="flex-1 h-12 font-medium"
            onClick={handleShare}
          >
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button 
            className="flex-1 h-12 gradient-bg text-white font-medium hover:opacity-90"
            onClick={handleExport}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
    </div>
  );
}
