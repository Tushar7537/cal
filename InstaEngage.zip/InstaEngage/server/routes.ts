import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEngagementCalculationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Engagement calculations endpoint
  app.post("/api/engagement-calculations", async (req, res) => {
    try {
      const data = insertEngagementCalculationSchema.parse(req.body);
      const calculation = await storage.createEngagementCalculation(data);
      res.json(calculation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid input data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get engagement calculations
  app.get("/api/engagement-calculations", async (req, res) => {
    try {
      const calculations = await storage.getEngagementCalculations();
      res.json(calculations);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Industry benchmarks endpoint
  app.get("/api/industry-benchmarks", async (req, res) => {
    try {
      const benchmarks = [
        { name: "E-commerce", average: 1.2, good: 2.0 },
        { name: "Fashion", average: 2.1, good: 3.0 },
        { name: "Food & Drink", average: 3.8, good: 5.0 },
        { name: "Business", average: 1.5, good: 2.5 },
        { name: "Fitness", average: 2.8, good: 4.0 },
        { name: "Travel", average: 2.4, good: 3.5 },
        { name: "Beauty", average: 3.2, good: 4.5 },
        { name: "Technology", average: 1.8, good: 2.8 },
      ];
      res.json(benchmarks);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
